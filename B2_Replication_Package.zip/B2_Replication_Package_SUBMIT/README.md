# Replication Package: Tokenomics as Institutional Design

## Citation

Zukowski, Z. (2026a). *Tokenomics as institutional design: A normative framework
and governance concentration analysis.* Frontiers in Blockchain, submitted.

Zukowski, Z. (2026b). *GeoDePIN: Design patterns for decentralized physical
infrastructure networks.* Blockchain: Research and Applications, submitted.

## Overview

This package contains all materials needed to replicate the empirical results in
both papers of the thesis "Tokenomics as Institutional Design for Decentralized
Physical Infrastructure Networks."

**Paper 1** analyzes governance token concentration (HHI, Gini, Top-N) across 13
protocols (7 DeFi/infrastructure benchmarks + 6 DePIN), finding that DePIN protocols
exhibit systematically higher concentration than DeFi counterparts (permutation test
p = 0.029, Mann-Whitney p = 0.075, rank-biserial r = 0.54). 12 protocols are
analyzable after Livepeer exclusion (Arbitrum schema limitation).

**Paper 2** traces Helium's Spend-to-Reward (S2R) ratio across 34 months
(May 2023 – February 2026), documenting the transition from subsidy-dependence
(S2R = 0.013) to net-deflationary operation (S2R = 1.84 using total-issuance
denominator; see DEC-001 in CHANGELOG.md), and profiles four additional DePIN
protocols (DIMO, Hivemapper, WeatherXM, IoTeX, GEODNET).

## Directory Structure

```
B2_Replication_Package_SUBMIT/
├── README.md                       # This file
├── CHANGELOG.md                    # Corrections applied since initial submission
├── LICENSE                         # CC-BY 4.0
├── dune_queries/
│   ├── 01_governance_hhi.sql       # Multi-chain governance concentration
│   ├── 02_helium_s2r.sql           # Helium monthly S2R (Solana)
│   ├── 03_dimo_s2r.sql             # DIMO license burn S2R (Polygon)
│   ├── 04_helium_who_burns.sql     # Helium DC burn concentration
│   ├── 05_defi_benchmarks.sql      # DeFi governance benchmarks
│   ├── 06_geodnet_burns.sql        # GEODNET monthly token burns (Solana)
│   ├── 07_geodnet_emissions.sql    # GEODNET monthly emissions (Solana)
│   ├── 08_geodnet_burn_concentration.sql  # GEODNET burn signer concentration
│   └── README.md                   # Query documentation
├── codebook/
│   ├── protocol_codebook.csv       # 14-protocol taxonomy (48+ fields)
│   ├── scoring_rubric.csv          # 8-lens normative scoring rubric
│   ├── scoring_sheet.csv           # Per-protocol scores (104 rows)
│   └── README.md                   # Field definitions, scoring procedure
├── scripts/
│   ├── compute_hhi.py              # HHI/Gini/Top-N from holder data
│   ├── compute_s2r.py              # Monthly S2R from burn/issuance data
│   ├── generate_figures.py         # Figure 1 (HHI bars) + Figure 2 (S2R timeline)
│   ├── statistical_tests.py        # DePIN vs DeFi permutation test + Mann-Whitney U
│   └── requirements.txt            # Python dependencies
└── data/
    ├── expected_results.csv        # Validation values for all key claims
    ├── helium_s2r_cleaned.csv      # 34-month Helium S2R trajectory (May 2023-Feb 2026)
    ├── geodnet_monthly_burns.csv   # GEODNET monthly GEOD burns
    ├── geodnet_monthly_emissions.csv  # GEODNET monthly GEOD emissions
    ├── governance_march2026.csv    # March 2026 governance re-query (consistent snapshot)
    └── statistical_test_results.csv  # Output of statistical_tests.py
```

## Requirements

- **Dune Analytics** account ([dune.com](https://dune.com), free tier sufficient)
- **Python 3.10+** with:
  - pandas >= 2.0
  - numpy >= 1.24
  - matplotlib >= 3.7
  - scipy >= 1.10
- Approximately **1-2 hours** to run all queries and scripts

## Quick Start

### 1. Install Python dependencies

```bash
cd scripts/
pip install -r requirements.txt
```

### 2. Run Dune queries and export CSVs

Open each `.sql` file in the Dune Analytics query editor:

1. Set the `{{snapshot_date}}` parameter to `2026-02-20` (or your replication date)
2. Run each query
3. Export results as CSV to the `data/` directory:
   - `01_governance_hhi.sql` -> `data/governance_hhi.csv`
   - `02_helium_s2r.sql` -> `data/helium_s2r.csv`
   - `03_dimo_s2r.sql` -> `data/dimo_s2r.csv`
   - `04_helium_who_burns.sql` -> `data/helium_burn_concentration.csv`
   - `05_defi_benchmarks.sql` -> `data/defi_benchmarks.csv`
   - `06_geodnet_burns.sql` -> `data/geodnet_burns_new.csv`
   - `07_geodnet_emissions.sql` -> `data/geodnet_emissions_new.csv`
   - `08_geodnet_burn_concentration.sql` -> `data/geodnet_burn_concentration_new.csv`

See `dune_queries/README.md` for chain-specific notes and troubleshooting.

### 3. Compute derived metrics

```bash
# HHI/Gini from holder data (if you exported raw holder balances)
python scripts/compute_hhi.py data/governance_hhi.csv data/governance_concentration.csv

# S2R from Helium burn/issuance data
python scripts/compute_s2r.py data/helium_s2r.csv data/s2r_computed.csv
```

### 4. Run statistical tests

```bash
python scripts/statistical_tests.py data/expected_results.csv data/statistical_test_results.csv
```

### 5. Generate figures

```bash
# From Dune CSV exports:
python scripts/generate_figures.py --data-dir data/ --output-dir data/

# Or using built-in expected values (no Dune export needed):
python scripts/generate_figures.py --use-expected --output-dir data/
```

### 6. Validate against expected results

Compare your outputs against `data/expected_results.csv`. Key values to check:

| Claim | Expected | Tolerance |
|-------|----------|-----------|
| Compound HHI | 0.028 | +/-0.005 |
| Anyone Protocol HHI | 0.009 | +/-0.003 |
| WeatherXM HHI | 0.593 | +/-0.010 |
| Helium S2R (May 2023) | 0.013 | +/-0.005 |
| Helium S2R (Feb 2026) | 1.840 | +/-0.10 |
| First S2R > 1.0 | October 2025 | exact |
| DIMO S2R | 4.24 | +/-0.50 |
| GEODNET S2R (Feb 2026) | 0.379 | +/-0.05 |
| Gini range | 0.72-0.98 | +/-0.02 |
| Permutation p (DePIN > DeFi HHI) | 0.034 | +/-0.006 |

## Statistical Tests

The paper reports a permutation test (p = 0.029) and Mann-Whitney U test (p = 0.075)
comparing DePIN vs DeFi HHI distributions. The script `scripts/statistical_tests.py`
reproduces these results from `data/expected_results.csv`.

```bash
python scripts/statistical_tests.py data/expected_results.csv data/statistical_test_results.csv
```

Expected output:
- Permutation p = 0.034 (DePIN mean HHI > DeFi mean HHI, 100K iterations, seed=42)
- Mann-Whitney p = 0.101 (one-sided, not significant at 10%)
- Rank-biserial r = 0.49 (medium-large effect)

## Data Freshness

All governance concentration values are based on a **February 20, 2026 snapshot**
(`snapshot_date = 2026-02-20`). Running queries at a later date will produce different
values due to ongoing token transfers, burns, and issuance.

A **March 2026 governance re-query** with a consistent snapshot date for all 12
protocols is provided in `data/governance_march2026.csv`. This resolves the 13-month
snapshot gap between DeFi (Jan 2025) and DePIN (Feb 2026) in the original data.
See CHANGELOG.md DEC-002 for details.

### Dune Labels Non-Determinism

The Dune Analytics `labels.addresses` table is community-maintained and grows
continuously. Queries using `NOT LIKE '%Exchange%'` to exclude exchange addresses
will produce different results when run at different times, even on the same snapshot
date. The governance HHI values in this paper reflect the labels state at the time
of original query execution (February 2026). A March 2026 re-run using the same
queries produced systematically lower HHI values across all protocols due to expanded
exchange labels, not due to token redistribution. Replicators should expect downward
drift in HHI values over time as more addresses are labeled.

For deterministic replication, the exchange exclusion list should ideally be
hardcoded. The paper's qualitative finding (DePIN concentration exceeds DeFi) is
robust at both the February and March 2026 query dates.

### Expected Drift

- **HHI values**: May shift +/-0.01-0.03 per month (labels drift + token transfers)
- **S2R values**: Historical months are stable; current month will differ
- **Gini coefficients**: Relatively stable (+/-0.01 per month)
- **Top-N shares**: Most volatile metric; whale movements cause swings

## Known Data Gaps

| Protocol | Gap | Reason |
|----------|-----|--------|
| Livepeer (LPT) | No HHI | Arbitrum schema prevented governance query |
| Hivemapper (HONEY) | No HHI | Solana token not indexed for governance in Dune |
| IoTeX (IOTX) | Partial | Uses Ethereum ERC-20 representation, not IoTeX L1 |
| WeatherXM (WXM) | No S2R | Subscription burn volumes too small for reliable ratio |
| GEODNET | Burns/emissions only | Full governance HHI not measured (token too new) |
| Wayru/WiFiDabba | Minimal | Pre-token or data-insufficient |
| IoTeX (IOTX) | Post-snapshot event | IoTeX bridge exploit Feb 21, 2026 (post-snapshot); HHI=0.388 reflects pre-exploit distribution |
| Anyone Protocol | Address corrected | Original address 0x2840... returned 0 rows; corrected to 0xFeAc...; HHI updated to 0.009 (DEC-003) |

## Methodological Notes

### HHI Computation
- Based on **top-1000 token holders** per protocol
- Exchange addresses excluded using Dune `labels.addresses` table
- Null address (0x000...000) and burn address (0x000...dEaD) excluded
- Shares normalized **within the top-1000 sample** (not total supply)
- HHI = sum(share_i^2) where share_i = balance_i / sum(top-1000 balances)

### Gini Computation (Brown's formula, richest-first ordering)
- Gini = 2*Z/(n*T) - (n+1)/n
- where Z = sum(share_i * (n+1-rank_i)), T = sum(share_i) = 1.0, n = 1000
- Note: The formula 1 - 2*Z/(n*T) is incorrect for richest-first ordering and
  produces negative Gini values. See CHANGELOG.md DEC-002 for details.

### S2R Computation
- S2R = monthly_burns / monthly_issuance
- Denominator variants (see DEC-001 in CHANGELOG.md):
  - Burns-only denominator: S2R_Feb2026 = 2.06 (PoC+data rewards only)
  - Total-issuance denominator: S2R_Feb2026 = 1.84 (rewards + delegation) -- paper uses this
- Fiscal regime thresholds: <0.10 subsidy-dependent, 0.10-0.35 emerging,
  0.35-1.0 approaching parity, >=1.0 net-deflationary

### Normative Scoring
- 8 philosophical lenses scored on 0-3 scale per `codebook/scoring_rubric.csv`
- Synergy Index = mean of 5 core lenses (Kantian, Rawlsian, Pettit, Ostrom, Hayek)
- Inter-rater reliability target: Cohen's kappa >= 0.70
- See `codebook/README.md` for full scoring procedure

## License

CC-BY 4.0. Data derived from public blockchain records via Dune Analytics.

## Contact

Zach Zukowski -- zach@tokenization.systems
