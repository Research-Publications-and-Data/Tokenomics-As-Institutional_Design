# Changelog

## 2026-03-29: Submission Preparation (Final)

### DEC-003: Anyone Protocol Address Correction

**Change:** Anyone Protocol HHI corrected from **0.034 to 0.009** in Table 4, `data/expected_results.csv`, and `data/governance_march2026.csv`. Gini updated from 0.79 to 0.72. Statistical test values updated (permutation p: 0.029→0.034, Mann-Whitney p: 0.075→0.101, effect size r: 0.54→0.49).

**Reason:** The original query used contract address `0x2840FDfb9B40218e8Af5eCA5F1c3E031C7577D9e`, which returned 0 rows in the March 2026 re-query (empty EOA — not the ANYONE token contract). The correct ANYONE token address is `0xFeAc2Eae96899709a43E252B6B92971D32F9C0F9`. A re-query at the Feb 20, 2026 snapshot with the corrected address (Dune query 6924078, execution 01KMYC9G8FNE2SVAMXAWF540HT) returned HHI = 0.009415, Gini = 0.722.

**Statistical impact:** The corrected HHI (0.009) is below the DeFi minimum (Compound 0.028), weakening the DePIN vs DeFi separation for this one protocol. The DePIN mean drops from 0.288 to 0.283 (still 3.05× the DeFi mean of 0.093). The permutation test remains significant at 5% (p = 0.034). The Mann-Whitney U result shifts from p = 0.075 to p = 0.101 (not significant at 10%). The effect size r = 0.49 is just below the Cohen "large" threshold of 0.50.

**Qualitative finding is robust:** Even with the corrected Anyone value, four of five DePIN protocols (Grass, DIMO, IoTeX, WeatherXM) substantially exceed the DeFi maximum (Curve, HHI = 0.174). The paper's core claim about systematic concentration differences is unchanged.

**Dune query:** 6924078 (temp query, Feb 20 2026 snapshot, corrected address, within-sample share normalization, correct Gini formula)

---



### DEC-001: Helium S2R Denominator Correction

**Change:** Helium S2R (Feb 2026) corrected from 2.06 to **1.84** in `data/expected_results.csv`
and `README.md`.

**Reason:** Two valid S2R denominator definitions exist:
- Burns-only denominator: HNT burned / PoC+data rewards only = 2.06
- Total-issuance denominator: HNT burned / (rewards + delegation rewards) = 1.84

The paper reports the total-issuance denominator (1.84) per author decision DEC-001
(2026-03-28). The burns-only value (2.06) is retained as a note in expected_results.csv
and in `data/helium_s2r_cleaned.csv` (column `s2r_burns_only`). Both values confirm
S2R > 1.0 by February 2026; the qualitative finding is robust to denominator choice.

**Source:** `s2r_measurement_memo_v2.md` in the depin-thesis archive.

---

### DEC-002: March 2026 Governance Re-Query

**Change:** Added `data/governance_march2026.csv` with a consistent March 28, 2026
snapshot for all 12 analyzable governance protocols.

**Reason:** The original `governance_hhi_gini_CORRECTED.csv` had a 13-month snapshot
gap: DeFi protocols used a January 2025 snapshot while DePIN protocols used February
2026. B2 Table 4 labels all data as "Feb 2026." The re-query resolves this inconsistency
for replicators.

**Method:** Five Dune queries (IDs 6923659-6923663) re-run with consistent March 28, 2026
snapshot date. Corrected Gini formula applied (see below). Results differ from B2 paper
values primarily due to **Dune labels table growth** (see note below), not genuine token
redistribution. The qualitative finding (DePIN more concentrated than DeFi) holds at both
snapshots.

**Labels non-determinism note:** The Dune Analytics `labels.addresses` table is
community-maintained and grows continuously. Queries using `NOT LIKE '%Exchange%'`
produce systematically lower HHI values when run later, because more exchange addresses
have been labeled since the original run. The March 2026 re-query produced HHI values
2–20× lower than the February 2026 paper values across all DeFi protocols (e.g., Compound:
0.028 → 0.011, Curve: 0.174 → 0.023), which is inconsistent with genuine redistribution
at that magnitude over a 1–2 month period. The normalization fix (within-sample shares)
would push HHI slightly UP, not down, confirming the dominant effect is label filtering.
Replicators running these queries today will see further downward drift. The February 2026
paper values, produced at the time of analysis, are the authoritative values for Table 4.

**Gini formula fix:** The formula `1 - 2*Z/(n*T)` (used in prior query versions) is
incorrect for richest-first holder ordering. It produces negative Gini values. The
correct Brown's formula for richest-first ordering is:
```
Gini = 2*Z/(n*T) - (n+1)/n
```
where Z = sum(share_i * (n+1-rank_i)), T = sum(share_i) = 1.0, n = 1000.
The relationship between the formulas is: correct = 1 - current_wrong - (n+1)/n.
For n=1000: correct ~= 1 - incorrect - 1.001.

**WXM contract address correction:** Previous queries used the wrong WXM contract
`0xB6093B61544572Ab42A0E43AF08aBaF6b3d2ad15` (an empty EOA). Correct contract:
`0xB6093B61544572Ab42A0E43AF08aBaFD41bf25A6`. The Feb 2026 paper value (HHI=0.584)
was from a retry query that may have used the correct address. Use the corrected
address for all future replication.

**Anyone Protocol note:** March 2026 re-query returned 0 rows for address
`0x2840FDfb9B40218e8Af5eCA5F1c3E031C7577D9e` (empty EOA — wrong address). Correct
address `0xFeAc2Eae96899709a43E252B6B92971D32F9C0F9` confirmed and used in DEC-003.
The original Feb 2026 paper value (0.034) was from a query on the wrong address and is
superseded by DEC-003.

---

### Corrections Applied

- `data/expected_results.csv`: Helium S2R peak corrected from 2.060 to 1.840 (DEC-001)
- `data/expected_results.csv`: Added GEODNET S2R, burns/emissions ratio, burn HHI
- `data/expected_results.csv`: Added statistical test result rows
- `data/expected_results.csv`: Anyone HHI corrected 0.034 → 0.009 (DEC-003)
- `data/expected_results.csv`: Anyone Gini corrected 0.79 → 0.72 (DEC-003)
- `data/expected_results.csv`: Gini range low corrected 0.79 → 0.72 (DEC-003)
- `data/expected_results.csv`: Statistical test values updated per DEC-003 (p_perm: 0.029→0.034, p_mw: 0.075→0.101, r: 0.54→0.49)
- `data/governance_march2026.csv`: Anyone Protocol row replaced with corrected address result (DEC-003)
- `scripts/statistical_tests.py`: Validation ranges updated per DEC-003
- `README.md`: Journal targets updated (Frontiers in Blockchain; Blockchain: Research
  and Applications)
- `README.md`: Contact updated to zach@tokenization.systems
- `README.md`: Protocol count clarified (13 sampled, 12 analyzable after Livepeer exclusion)
- `README.md`: Added statistical tests section; added Gini formula note
- `README.md`: Snapshot date specified as February 20, 2026
- `README.md`: Added labels non-determinism note; updated validation table and stats section per DEC-003
- `README.md`: Added IoTeX bridge exploit note (Feb 21, 2026 post-snapshot event)

### New Files Added

- `dune_queries/06_geodnet_burns.sql`: GEODNET monthly token burns (Dune query 6917159)
- `dune_queries/07_geodnet_emissions.sql`: GEODNET monthly emissions (Dune query 6923474)
- `dune_queries/08_geodnet_burn_concentration.sql`: GEODNET burn signer HHI (Dune 6917162)
- `scripts/statistical_tests.py`: DePIN vs DeFi permutation test and Mann-Whitney U
- `scripts/requirements.txt`: Added scipy >= 1.10 dependency
- `data/helium_s2r_cleaned.csv`: 34-month Helium S2R trajectory (May 2023 to Feb 2026)
- `data/geodnet_monthly_burns.csv`: GEODNET monthly GEOD burn data (Dune 6917159 export)
- `data/geodnet_monthly_emissions.csv`: GEODNET monthly emission data (Dune 6923474 export)
- `data/governance_march2026.csv`: March 2026 consistent-snapshot governance re-query
- `data/statistical_test_results.csv`: Output of statistical_tests.py
- `CHANGELOG.md`: This file
- `LICENSE`: CC-BY 4.0

### Data Provenance Notes

- The S2R measurement memo (`s2r_measurement_memo_v2.md`) in the thesis archive uses
  the burns-only denominator (S2R = 2.06). The paper uses total-issuance (S2R = 1.84).
  Both variants are now documented in expected_results.csv.
- WXM and Anyone Protocol data in the Feb 2026 snapshot came from retry queries and
  are not in the original corrected CSV. Recomputed values match Table 4 within tolerance.
- GEODNET S2R (0.379) is based on the DATA_REGISTRY burn channel only. Other GEOD burn
  channels may exist; see claim1_verdict.txt in the claim verification archive.
